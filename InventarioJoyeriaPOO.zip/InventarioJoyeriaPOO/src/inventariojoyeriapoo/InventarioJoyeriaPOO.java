/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package inventariojoyeriapoo;

/**
 *
 * @author Sara.Reyna
 */
public class InventarioJoyeriaPOO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //PRuebaFrame FM = new PRuebaFrame();
        
        //FM.setVisible(true);
        InicioSesion IS = new InicioSesion();
        
        
        IS.setVisible(true);
    }
    
    
    
}
